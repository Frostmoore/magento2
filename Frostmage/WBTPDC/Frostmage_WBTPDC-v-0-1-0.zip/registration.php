<?php
/**
 * Copyright 2018 Ditta individuale See My Page di Riccardo Ronconi.
 * All rights reserved. See COPYING.txt for license details.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Frostmage_WBTPDC',
    __DIR__
);
